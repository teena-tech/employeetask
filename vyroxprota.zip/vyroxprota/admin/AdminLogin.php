<!DOCTYPE html>
<html>

<head>
    <title>Admin Login</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script>
    addEventListener("load", function() {
        setTimeout(hideURLbar, 0);
    }, false);

    function hideURLbar() {
        window.scrollTo(0, 1);
    }
    </script>


    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />
    <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all" />



    <link href="//fonts.googleapis.com/css?family=Hind:300,400,500,600,700" rel="stylesheet">


</head>

<body>



    <h1 style="color: black;text-shadow: 1px 1px 8px black;">Admin login here..</h1>
    <div class="header-main">
        <div class="main-icon">
            <span class="fa fa-eercast"></span>
        </div>
        <img src="images/logo.png">
        <div class="header-left-bottom">
            <form action="#" method="post">
                <div class="icon1">

                    <input type="email" placeholder="Email Address" name="email" required="" />
                </div>
                <div class="icon1">

                    <input type="password" placeholder="Password" name="password" required="" />
                </div>
                <div class="bottom">
                    <button class="btn" type="submit" name="submit">Log In</button>
                </div>
                <div class="links">
                    <p class="right"><a href="../index.php">Users..? Login Here</a></p>
                    <div class="clear"></div>
                </div>
            </form>
        </div>
    </div>

    </div>
    </div>
    <!-- //main -->

    <?php
  error_reporting(-1);
ini_set('display_errors', 'On');
  session_start();
  require '../Classes/init.php';
  $func = new Operation();

  
  if(isset($_POST['submit']))
  {     
    $invalidErr="";
    $email = $_POST["email"]; 
    $password = $_POST["password"];  
    $status=1;        

    

    $result = $func->select_with_multiple_conditions(array('*'),'admin',"admin_email = '".$email."'",'AND',"admin_password = '".$password."'","admin_status = '".$status."'");

    while($row = $result->fetch_assoc())
    {
     $myId=$row["admin_id"];
     }             
   session_regenerate_id();
   $_SESSION['admin_id']=$myId;             
   session_write_close();

   if ($result->num_rows > 0 )
   {                  
     header("location: AdminHome.php");
   }   
   else
   {
    $message="Invalid username Or Password..!!";
    echo "<script type='text/javascript'>alert('$message');</script>";
   }                 
  }
?>
</body>

</html>