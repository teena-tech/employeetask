<?php
$timeout=200;
set_time_limit($timeout+1);//Maximum execution time.
flushBrowser();//Print space chars to have cache flush on browsers.
$str='';
while ($timeout>0){
    //Flush data to display
    ob_flush();
    flush();
if ($str!=checkPostMsgQueued())
echo checkPostMsgQueued()."\n";
$str=checkPostMsgQueued();
    //wait...
    sleep(1);
    $timeout-=1;
}
ob_end_flush();


//Many browsers seems to receive some data before flushing.
function flushBrowser(){
if (ob_get_level() == 0) ob_start();
echo str_pad('',4096)."\n";   
}
function checkPostMsgQueued(){
        $filename="testChat.txt";
        if (file_exists($filename)){
            $stream=fopen($filename, 'r');
            $str=stream_get_line($stream,128);
            fclose($stream);
        }
        return $str;
}