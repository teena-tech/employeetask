<!DOCTYPE html>
<html>

<head>
    <title></title>
</head>

<body>
    <form action="testChatSubmit.php" method="post">
        <input type="text" name="message" id="message">
        <input type="submit" name="submit">
    </form>
</body>

</html>
<?php
if (isset($_POST['message'])){
$fp = fopen('testChat.txt', 'w');
fwrite($fp, $_POST['message']);
fclose($fp);
}
?>